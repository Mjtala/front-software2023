/* eslint-disable import/prefer-default-export */
export const users = [
  {
    id: 0,
    name: "Gonzalo",
  },
  {
    id: 1,
    name: "Will Smith",
  },
  {
    id: 2,
    name: "Best name",
  },
];
